import java.io.FileNotFoundException;

public class Main
{
    public static void main(String[] args) throws FileNotFoundException
    {

        Bullseye b = new Bullseye();
        System.out.println(b.read());


    }
}